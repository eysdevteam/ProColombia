var app = angular.module('galatea', []);


